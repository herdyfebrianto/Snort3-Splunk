--[[
# Copyright 2001-2014 Cisco Systems, Inc. and/or its affiliates. All rights
# reserved.
#
# This file contains proprietary Detector Content created by Cisco Systems,
# Inc. or its affiliates ("Cisco") and is distributed under the GNU General
# Public License, v2 (the "GPL").  This file may also include Detector Content
# contributed by third parties. Third party contributors are identified in the
# "authors" file.  The Detector Content created by Cisco is owned by, and
# remains the property of, Cisco.  Detector Content from third party
# contributors is owned by, and remains the property of, such third parties and
# is distributed under the GPL.  The term "Detector Content" means specifically
# formulated patterns and logic to identify applications based on network
# traffic characteristics, comprised of instructions in source code or object
# code form (including the structure, sequence, organization, and syntax
# thereof), and all documentation related thereto that have been officially
# approved by Cisco.  Modifications are considered part of the Detector
# Content.
--]]
--[[
detection_name: Content Group "Process Group 352"
version: 1
description: Group of Process Name to Client App detectors.
bundle_description: $VAR1 = {
          'Apple Maps' => 'Apple maps and navigation.',
          'Twitter' => 'Social networking and microblogging site.',
          'Kaspersky Network Agent' => 'Kaspersky Network Agent facilitates interaction between the Administration server and Kaspersky lab products.',
          'TuneIn' => 'Online Radio station.',
          'Hotspot Shield' => 'Anonymizer and tunnel that encrypts communications.',
          'Rakuten' => 'Japanese e-commerce site.',
          'WhatsApp' => 'A cross-platform mobile messaging app which serves as a free alternative to SMS messages.',
          'TweetDeck' => 'Dashboard application to manage both Twitter and Facebook.',
          'Minecraft' => 'Online game.',
          'Box' => 'File storage and transfer site.',
          'Cisco Secure Endpoint' => 'Cloud-based real time antivirus protection. (AMP for Endpoints)',
          'LogMeIn' => 'Remote access and PC desktop control.',
          'OpenDNS' => 'DNS service for reliability and security for internet surfers.',
          'GitHub' => 'Code management portal for open Source projects.',
          'Jira' => 'Web based bug tracking and project management tool.',
          'Sharepoint' => 'Microsoft collaboration, file sharing and web publishing system.',
          'Duo Security' => 'A user-centric access security platform that provides two-factor authentication, endpoint security, remote access solutions and a subsidiary of Cisco.',
          'McAfee' => 'McAfee Antivirus/Security software download and updates.',
          'Quake' => 'First person shooter.',
          'RDP' => 'Remote Desktop Protocol provides users with a graphical interface to another computer.',
          'Chrome' => 'Google\'s web browser.',
          'Apple TV' => 'Apple device to receive the media traffics from Internet or Local networks.',
          'Quicken' => 'Intuit personal finance software.',
          'NetNewsWire' => 'News feed and aggregator for iOS.',
          'Linphone' => 'VoIP application using SIP.',
          'PaleMoon' => 'A web browser.',
          'Basecamp' => 'Web based project management tool.',
          'Upwork' => 'Global freelancing platform for businesses and independent professionals be connected.',
          'Squid' => 'HTTP Proxy server.',
          'rlogin' => 'Unix utility that allows remote administration from one computer to another.',
          'Autodesk' => 'A CAD and 3D printing software company,',
          'Java' => 'Java based application.',
          'SSH' => 'Secure Shell is a network protocol that allows data to be exchanged using a secure channel between two networked devices.',
          'Tableau' => 'Tableau Software is an interactive data visualization and data analytics software which provides pictorial and graphical representations of data.',
          'Resilio Sync' => 'Syncs files and folders across devices. Formerly BitTorrent Sync.',
          'Microsoft Visual Studio' => 'Microsoft Integrated Developer Environment and toolchain designed to make it easier to develop software for Microsoft platforms.',
          'Yandex Disk' => 'A Yandex cloud storage product.',
          'SVN' => 'Managing Subversion servers.',
          'device' => 'Registered with IANA on port 801 TCP/UDP.',
          'Epic' => 'Software that uses the Health Level 7 protocol.',
          'Signal' => 'Signal is a cross-platform centralized encrypted messaging service developed by the Signal Technology Foundation and Signal Messenger LLC.',
          'TunnelBear' => 'An anonymization service.',
          'Kaspersky' => 'Kaspersky Antivirus/Security software download and updates.',
          'Syncplicity' => 'Data synch service.',
          'HTTP' => 'HTTP (HyperText Transfer Protocol) the principal transport protocol for the World Wide Web.',
          'Ngrok' => 'Multiplatform tunnelling, reverse proxy software.',
          'Wow' => 'A search engine.',
          'Zoho Assist' => 'A remote support and remote access software.',
          'iTunes' => 'Apple\'s media player and online store.',
          'Evolution' => 'Gnome email client.',
          'Pocket' => 'App to save web pages.',
          'ADrive' => 'Online file storage and backup.',
          'Dropbox' => 'Cloud based file storage.',
          'Splunk' => 'System log aggregator.',
          'Bria' => 'VoIP based software for video calls and instant messaging.',
          'Messenger' => 'Facebook\'s standalone messenger app.',
          'Nmap' => 'Network Mapper, a security scanner.',
          'Deezer' => 'Music streaming service based in Paris.',
          'Fuze' => 'A team collaborative call and messaging tool.',
          'Edge' => 'Microsoft web browser.',
          'Baidu' => 'Chinese Search engine.',
          'cURL' => 'Utility for HTTP access.',
          'Grammarly' => 'Digital writing tool using artificial intelligence and natural language processing (auto corecting tool)',
          'TOR' => 'The Onion Router. A client which allows a user to send and relay internet traffic anonymously.',
          'Prezi' => 'Presentation tool.',
          'TwitchTV' => 'Justin.tv gaming specific livestreaming platform.',
          'PHP' => 'Scripting language for developing server based web applications.',
          'iHeartRadio' => 'Website that provides streaming access to local and digital-only radio stations.',
          'AnyConnect' => 'Cisco VPN server.',
          'WeatherBug' => 'Windows weather application.',
          'Wget' => 'Application that allows HTTP access.',
          'BitDefender' => 'BitDefender Antivirus/Security software download and updates.',
          'AnyDesk' => 'Remote Desktop Access Software.',
          'Office 365' => 'Traffic generated by MS Office 365 applications and web services.',
          'JetBrains' => 'A collection of IDEs for different programming languages and frameworks.',
          'Apple News' => 'Apple News is an app the brings news and magazines, all in one place.',
          'Battle.net' => 'Game networking service.',
          'Feedly' => 'News Aggregator.',
          'Canva' => 'Graphic design software.',
          'World of Warcraft' => 'Massively multiplayer online role-playing game.',
          'Yandex' => 'Russian search engine.',
          'Eclipse' => 'Software Updates for Eclipse.',
          'Flock' => 'A web browser.',
          'Windscribe' => 'VPN traffic generated by Windscribe.',
          'Anghami' => 'Music streaming site.',
          'Viber' => 'Smartphone app that allows for free phone calls and text messages.',
          'Google Earth' => 'Google\'s virtual globe, map and geographical information program.',
          'WeChat' => 'Mobile text and voice messaging application.',
          'ICQ' => 'Internet chat client.',
          'Launchpad' => 'Web based bug tracking and project management tool.',
          'Shazam' => 'Media Playing and sharing application.',
          'Evernote' => 'Synched note taking and web bookmarking app.',
          'ExpressVPN' => 'A paid VPN platform with desktop and mobile apps.',
          'TurboTax' => 'Intuit tax preparation software.',
          'BitTorrent' => 'A peer-to-peer file sharing protocol used for transferring large amounts of data.',
          'Discord' => 'VoIP, instant messaging and digital distribution platform designed for creating communities.',
          'Amazon Cloud Player' => 'Media player by Amazon facilitates listening music from cloud or download on the device.',
          'TeamViewer' => 'Remote desktop control and file transfer software.',
          'Speedtest' => 'Test the download and upload speed of the internet.',
          'Draw.io' => 'Online diagram and flowchart application.',
          'PTP' => 'Performance Transparency Protocol.',
          'CloudApp' => 'Data synch and collaboration app.',
          'Nielsen' => 'Global information and measurement company.',
          'Groove' => 'Microsoft desktop application designed for document collaboration.',
          'Kugou' => 'Peer-to-peer music.',
          'Meter' => 'Registered with IANA on port 570 TCP/UDP.',
          'iCloud' => 'Apple cloud storage service.',
          'Trend Micro' => 'Security software company.',
          'MelOn' => 'Korean music site.',
          'MongoDB' => 'Source-available cross-platform document-oriented database program.',
          'Webshots' => 'Service for uploading and sharing photos and videos.',
          'Xcode' => 'Apple\'s IDE.',
          'Nessus' => 'Active network scanner.',
          'DocuSign' => 'Secure electronic document signing.',
          'PDF Expert' => 'App for iPad to view and endit PDF files.',
          'LastPass' => 'Password management application.',
          'Google Drive' => 'A free office suite and cloud storage system hosted by Google.',
          'Clip2Net' => 'Yandex cloud storage that acts like a clipboard.',
          'Skype' => 'A software application that allows users to chat, make voice/video calls, and transfer files over the Internet.',
          'LINE' => 'Mobile and Desktop App for Instant Messaging.',
          'Stripe' => 'Stripe provides payment processing platforms',
          'Instapaper' => 'App to save wb pages for later use.',
          'RingCentral' => 'RingCentral is an American publicly traded provider of cloud-based communications and collaboration solutions for businesses.',
          'QQ' => 'Chinese instant messaging software.',
          'Apple Stocks' => 'Stock related updates.',
          'Roblox' => 'Online gaming platform.',
          'Facetime' => 'Apple video conferencing software.',
          'Steam' => 'Massive gaming and communications platform.',
          'WebEx' => 'Cisco\'s online meeting and web conferencing application.',
          'Libwww-Perl' => 'Library for World wide web service.',
          'Firefox' => 'A mozilla web browser.',
          'Monitor' => 'Registered with IANA on port 561 TCP/UDP.',
          'BlueJeans' => 'An interoperable cloud-based video conferencing service.',
          'Google Calendar' => 'A free time-management web application offered by Google.',
          'SugarSync' => 'Cloud-based backup service.',
          'Aliwangwang' => 'Instant messaging.',
          'GoodSync' => 'File transfer and synchronization service.',
          'Asana' => 'Collboration service.',
          'Kodi' => 'Open source media player.',
          'Honey' => 'Digital tool to find the best savings, perks, and all around value, coupons and discounts',
          'Ninite' => 'A tool that manages installation and upgrading of apps.',
          'Atom' => 'Atom is a web content syndication system similar to RSS.',
          'Python urllib' => 'Python library for opening URLs.',
          'Zoom' => 'Remote conferencing via cloud computing.',
          'Telegram' => 'Telegram is a messaging app with a focus on speed and security.',
          'Power BI' => 'Power BI is a business analytics service by Microsoft which aims to provide interactive visualizations and business intelligence capabilities.',
          'Avast' => 'Anti-virus software for Windows PCs.',
          'Snapchat' => 'Online photo sharing.',
          'GoToMeeting' => 'Online meeting and desktop sharing service.',
          'KakaoTalk' => 'Mobile messaging for smartphones.',
          'Pandora' => 'Audio streaming.',
          'RealVNC' => 'A VNC package that supports client and server side, and also provides cloud-based services such as chat and file transfer.',
          'Thunderbird' => 'Mozilla email client.',
          'Eudora' => 'email client.',
          'Tanium' => 'Endpoint security and systems management software.',
          'WinSCP' => 'A free SFTP and FTP client for Windows.',
          'Glide' => 'Cross-platform web desktop that allows for file sharing between different computers and mobile devices.',
          'Internet Explorer' => 'A Microsoft web browser.',
          'DDM' => 'IBM Lotus Domino domain monitoring, a management system for Domino networks.'
        };

--]]

require "DetectorCommon"

local DC = DetectorCommon

DetectorPackageInfo = {
    name = "content_group_process_client_352",
    proto =  DC.ipproto.tcp,
    client = {
        init =  'DetectorInit',
        clean =  'DetectorClean',
        minimum_matches =  1
    }
}

gProcessClientList = {
   --ADrive
    {17, "adrive", 90},
     --BitDefender
    {59, "bitdefender", 90},
    --BitTorrent
    {61, "bittorrent", 90},
    --Dropbox
    {125, "dropbox", 90},
    --Google Drive
    {180, "google drive", 90},
    --GoToMeeting
    {187, "go to meeting", 90},
    --Kaspersky
    {248, "avp", 90},
    --Kugou
    {256, "kugou", 90},
    --LogMeIn
    {270, "logmein", 90},
    --McAfee    
    {280, "mcafee", 90},
    --QQ
    {386, "qq", 90},
    --rlogin
    {398, "rlogin", 90},
    --Sharepoint
    {423, "microsoft.sharepoint", 90},
    --TOR
    {473, "tor", 90},
    --World of Warcraft
    {507, "world of warcraft", 90},
    --Atom
    {555, "atom", 90},
    --Basecamp
    {563, "basecamp", 90},
    --Battle.net
    {564, "battle.net", 90},
    --Chrome
    {589, "chromium", 90},
    --cURL
    {596, "curl", 90},
    --Eudora
    {624, "eudora", 90},
    --Evolution
    {626, "evolution", 90},
    --Firefox
    {638, "firefox", 90},
    --Google Calendar
    {661, "google calendar", 90},
    --Google Earth
    {672, "google earth", 90},
    --HTTP
    {676, "http", 90},
    --ICQ
    {679, "icq", 90},
    --Internet Explorer
    {686, "explorer", 90},
    --iTunes
    {689, "icloud/itunes tools", 90},
    --Jira
    {695, "jira", 90},
    --Launchpad
    {708, "launchpad", 90},
    --Nessus
    {752, "nessus", 90},
    --Pandora
    {779, "pandora", 90},
    --Quake
    {795, "quake", 90},
    --RDP
    {803, "microsoft remote desktop", 90},
    --Skype
    {832, "skype", 90},
    --Squid
    {844, "squid", 90},
    --SSH
    {846, "ssh", 90},
    --Thunderbird
    {866, "thunderbird", 90},
    --Twitter
    {882, "twitter", 90},
    --WebEx
    {905, "cisco webex", 90},
    --Wget
    {909, "wget", 90},
    --Cisco Secure Endpoint
    {934, "cisco amp for endpoints", 90},
    --TeamViewer
    {958, "team viewer", 90},
    --Deezer
    {965, "deezer", 90},
    --iHeartRadio
    {984, "iheartradio", 90},
    --Webshots
    {1021, "webshots", 90},
    --TwitchTV
    {1051, "twitch", 90},
    --Steam
    {1086, "steam", 90},
    --Hotspot Shield
    {1140, "hotspot shield", 90},
    --WhatsApp
    {1143, "whatsapp", 90},
    --Facetime
    {1186, "facetime", 90},
    --iCloud
    {1187, "icloud", 90},
    --Avast
    {1264, "avast", 90},
    --Evernote
    {1267, "evernote", 90},
    --Box
    {1326, "box", 90},
    --Baidu
    {1345, "baidu", 90},
    --TweetDeck
    {1360, "tweetdeck", 90},
    --KakaoTalk
    {1405, "kakaotalk", 90},
    --Apple Stocks
    {1407, "apple stocks", 90},
    --Eclipse
    {1413, "eclipse", 90},
    --WeatherBug
    {1421, "weatherbug", 90},
    --Libwww-Perl
    {1430, "perl", 90},
    --PaleMoon
    {1592, "palemoon", 90},
    --Xcode
    {1602, "xcode", 90},
    --Bria
    {1604, "bria", 90},
    --Linphone
    {1606, "linphone", 90},
    --Yandex
    {1616, "yandex", 90},
    --Rakuten
    {1652, "rakuten", 90},
    --Snapchat
    {1653, "snapchat", 90},
    --LINE
    {1667, "line", 90},
    --GitHub
    {1670, "git", 90},
    {1670, "github", 90},
    --Trend Micro
    {1671, "trend micro antivirus", 90},
    --Apple TV
    {1683, "tv", 90},
    --Java
    {1692, "java", 90},
    --Feedly
    {1799, "feedly", 90},
    --Minecraft
    {1802, "minecraft", 90},
    --TuneIn
    {1810, "tunein", 90},
    --SugarSync
    {1819, "sugarsync", 90},
    --Splunk
    {2037, "splunk", 90},
    --Prezi
    {2040, "prezi", 90},
    --Epic
    {2096, "epic", 90},
    --Speedtest
    {2103, "speedtest", 90},
    --PHP
    {2230, "php", 90},
    --PDF Expert
    {2307, "pdf expert", 90},
    --NetNewsWire
    {2324, "netnewswire", 90},
    --Viber
    {2367, "viber", 90},
    --Apple Maps
    {2381, "maps", 90},
    --Pocket
    {2431, "pocket", 90},
    --Instapaper
    {2434, "instapaper", 90},
    --Nielsen
    {2468, "nielsenonline", 90},
    --Aliwangwang
    {2617, "aliwangwang", 90},
    --WeChat
    {2618, "wechat", 90},
    --Resilio Sync
    {2667, "resilio sync", 90},
    --Python urllib
    {2685, "python", 90},
    --GoodSync
    {2688, "goodsync", 90},
    --OpenDNS
    {2704, "cisco umbrella", 90},
    --Kodi
    {2758, "kodi", 90},
    --Amazon Cloud Player
    {2781, "amazon music", 90},
    --Office 365
    {2812, "microsoft office", 90},
    --Glide
    {2827, "glide", 90},
    --SVN
    {2887, "svn", 90},
    --AnyConnect
    {2921, "cisco anyconnect", 90},
    --device
    {3095, "device", 90},
    --DDM
    {3109, "ddm", 90},
    --Groove
    {3139, "groove", 90},
    --Meter
    {3214, "meter", 90},
    --Monitor
    {3228, "monitor", 90},
    --Nmap
    {3248, "nmap", 90},
    --PTP
    {3623, "ptp", 90},
    --MelOn
    {3659, "melon", 90},
    --Flock
    {3765, "flock", 90},
    --Clip2Net
    {3782, "clip2net", 90},
    --TunnelBear
    {3857, "tunnelbear", 90},
    --Autodesk
    {3888, "autodesk fusion", 90},
    --Wow
    {3910, "wow", 90},
    --Quicken
    {3937, "quicken", 90},
    --TurboTax
    {3938, "turbotax", 90},
    --Asana
    {3950, "asana", 90},
    --DocuSign
    {3955, "docusign", 90},
    --Draw.io
    {3956, "draw.io", 90},
    --Microsoft Visual Studio
    {3979, "microsoft visual studio", 90},
    --JetBrains
    {3981, "jetbrains", 90},
    --CloudApp
    {4021, "cloudapp", 90},
    --Syncplicity
    {4027, "syncplicity", 90},
    --Ninite
    {4035, "ninite", 90},
    --Yandex Disk
    {4049, "yandex disk", 90},
    --Edge
    {4057, "edge", 90},
    --Messenger
    {4073, "facebook messenger", 90},
    --Tanium
    {4076, "tanium", 90},
    --Anghami
    {4103, "anghami", 90},
    --Telegram
    {4116, "telegram", 90},
    --Ngrok
    {4134, "ngrok", 90},
    --Shazam
    {4138, "shazam", 90},
    --RealVNC
    {4142, "vncviewer", 90},
    --AnyDesk
    {4145, "anydesk", 90},
    --BlueJeans
    {4151, "bluejeans", 90},
    --LastPass
    {4155, "lastpass", 90},
    --Roblox
    {4193, "roblox", 90},
    --Canva    
    {4250, "canva", 90},
    --Upwork
    {4358, "upwork", 90},
    --Zoom
    {4513, "zoom", 90},
    --ExpressVPN
    {4519, "expressvpn", 90},
    --Power BI
    {4520, "power bi", 90},
    --Windscribe
    {4541, "windscribe", 90},
    --Zoho Assist
    {4550, "zoho assist", 90},
    --Kaspersky Network Agent
    {4558, "ksde", 90},
    --Fuze
    {4559, "fuze", 90},
    --Grammarly
    {4598, "grammarly", 90},
    --Honey
    {4599, "honey coupons", 90},
    --Stripe
    {4614, "stripe", 90},
    --Apple News
    {4623, "apple news", 90},
    --RingCentral
    {4635, "ringcentral", 90},
    --Tableau
    {4636, "tableau", 90},
    --Signal
    {4643, "signal", 90},
    --MongoDB
    {4644, "mongod", 90},
    --Duo Security
    {4648, "duo", 90},
    --Discord
    {4654, "discord", 90},
    --WinSCP
    {4658, "winscp", 90},
}

function DetectorInit(detectorInstance)
    gDetector = detectorInstance;
    if gDetector.addContentTypePattern then
        for i,v in ipairs(gProcessClientList) do
            gDetector:addProcessToClientMapping(v[1], v[2], v[3]);
        end
    end
    gProcessClientList = nil
    return gDetector;
end

function DetectorClean()
end
